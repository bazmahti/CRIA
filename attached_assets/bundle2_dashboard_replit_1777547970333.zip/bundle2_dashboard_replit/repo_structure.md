# Proposed GitHub Repository Structure

*For `bazmahti/aria-dashboard` — the dashboard repo that runs ARIA experiment artefacts.*

---

## Directory layout

```
aria-dashboard/                          # repo root
│
├── README.md                            # what this repo is, how to use it
├── LICENSE                              # MIT or similar
├── .gitignore                           # standard Python/Replit ignores
├── .replit                              # Replit config (entry point, packages)
├── replit.nix                           # Replit nix config if needed
│
├── pending_experiments/                 # Dr Ferrier saves new artefacts here
│   ├── .gitkeep
│   └── (artefact YAML files appear here, get processed, get moved out)
│
├── completed_experiments/               # dashboard moves processed artefacts here
│   ├── .gitkeep
│   └── 2026-04-30_HHMMSS_experiment_id/
│       ├── artefact.yaml                # the original artefact
│       ├── stdout.log                   # asie_hub stdout
│       ├── stderr.log                   # asie_hub stderr
│       ├── findings.md                  # parsed findings (markdown)
│       ├── findings_metadata.json       # structured metadata
│       │   {                            #   - tier achieved
│       │   }                            #   - convergence detected
│       │                                #   - position-privilege distribution
│       │                                #   - dissonance budget actually applied
│       │                                #   - cost incurred (AUD)
│       │                                #   - duration
│       │                                #   - falsification result
│       └── citations.json               # structured citation metadata
│
├── schemas/
│   ├── experiment_artefact_v1.json      # JSON schema for validation
│   └── findings_metadata_v1.json        # schema for findings output
│
├── templates/                           # starter templates for common experiments
│   ├── channel_specific_finding.yaml    # e.g. find evidence in chronic_pain
│   ├── cross_cultural_validity.yaml     # framework stress-test
│   ├── frame_extinction_audit.yaml      # what perspectives have dropped out
│   ├── reflexivity_quarterly.yaml       # ARIA-on-ARIA self-audit
│   └── README.md                        # how to use templates
│
├── dashboard/                           # the Replit-deployed app
│   ├── app.py                           # entry point (Flask/FastAPI/Streamlit)
│   ├── runner.py                        # invokes asie_hub CLIs
│   ├── validator.py                     # JSON schema validation
│   ├── findings_renderer.py             # markdown → HTML rendering
│   ├── reflexivity.py                   # quarterly self-audit logic
│   ├── static/                          # CSS, JS
│   ├── templates/                       # HTML templates (if Flask)
│   └── tests/
│       ├── test_validator.py
│       ├── test_runner.py
│       └── fixtures/
│           └── valid_artefact.yaml
│
├── docs/
│   ├── ARIA_Dashboard_Experiment_Artefact_Spec.md   # canonical spec
│   ├── architecture.md                              # how the dashboard works
│   ├── deployment.md                                # Replit deployment notes
│   └── faq.md
│
├── scripts/
│   ├── migrate_to_v2.py                 # migration helper if schema evolves
│   ├── batch_run.py                     # run all pending in one go (CLI)
│   └── reflexivity_report.py            # generate quarterly report
│
└── requirements.txt                     # pinned Python deps
```

---

## Key conventions

### Experiments are files

Every experiment is a YAML file. Files version with git. The git history *is* the audit trail of what was asked, when, by whom, with what parameters. The strange-loop discipline (ARIA studies its own behaviour) requires this trail.

### Pending → Completed flow

- Drop YAML into `pending_experiments/`
- Dashboard validates, runs, captures
- Dashboard *moves* (not copies) the artefact into `completed_experiments/{timestamp}_{experiment_id}/`
- The pending folder always reflects "what's queued"; completed folder always reflects "what's done"

### Naming

- `experiment_id` is snake_case, lowercase, alphanumeric + underscores
- Completed folder names are `{ISO-date-with-time}_{experiment_id}` for easy sorting
- Findings files inside completed folders use fixed names (`findings.md`, `stdout.log`, etc.) so the dashboard can always find them

### Branches

- `main` — stable
- `feature/*` — experimental dashboard features
- `experiments/*` — for forking experiments (e.g. running same artefact with different dissonance budgets to compare)

Experiments themselves don't go on branches. They go in main, in their respective folders. Branches are for code work.

---

## What lives outside this repo

These belong elsewhere, not in `aria-dashboard`:

- **asie_hub itself** — that's at `~/Documents/Projects/OpenClaw/skills/asie_hub/` and it's its own thing. Dashboard *invokes* it via subprocess; doesn't bundle it.
- **Book chapter drafts** — those live in the relevant Claude project's exports or in a separate writing repo. The dashboard surfaces *findings*, not chapters.
- **Partnership-bound material** — community-curated content, anything tagged SILO. Stays in the silo, never touches this repo.
- **Personal credentials** — API keys, tokens, etc. live in Replit secrets / environment variables, not in `.env` files in the repo.

---

## .gitignore essentials

```
# Python
__pycache__/
*.pyc
*.pyo
.venv/
venv/
.env
.env.local

# Replit
.upm/
.config/

# Operating system
.DS_Store
Thumbs.db

# IDE
.vscode/
.idea/

# Dashboard runtime artifacts
dashboard/instance/
dashboard/cache/
*.log
```

Note: `*.log` is in `.gitignore` *globally*, but `completed_experiments/*/stdout.log` and `stderr.log` are committed because they're work product, not runtime logs. Either un-ignore that subdirectory in `.gitignore` or use `git add -f` for those specific files.

---

## Replit deployment notes

For initial deployment:

```nix
# replit.nix (skeleton)
{ pkgs }: {
  deps = [
    pkgs.python311
    pkgs.python311Packages.flask
    pkgs.python311Packages.pyyaml
    pkgs.python311Packages.jsonschema
    pkgs.python311Packages.markdown
  ];
}
```

```
# .replit (skeleton)
run = "python3 -m dashboard.app"
language = "python3"
```

The dashboard needs network access to invoke asie_hub on the local Mac (which holds the actual ARIA codebase). Two options for production:

**Option A (recommended for V0/V1):** Run dashboard locally on the Mac. Replit hosts the development environment but the dashboard runs `subprocess.run` on the local asie_hub. Works for single-user (Dr Ferrier on one Mac).

**Option B (V2+):** asie_hub gets containerised and deployed alongside the dashboard. Multi-machine. More complex. Don't do this until Option A is hitting real limits.

---

## Initial commit checklist

- [ ] README.md describing the repo
- [ ] LICENSE file
- [ ] .gitignore with the essentials
- [ ] schemas/experiment_artefact_v1.json
- [ ] templates/ with at least the four starter templates
- [ ] dashboard/ skeleton with app.py, runner.py, validator.py
- [ ] requirements.txt with pinned versions
- [ ] docs/ARIA_Dashboard_Experiment_Artefact_Spec.md (canonical spec)
- [ ] An empty pending_experiments/ with .gitkeep
- [ ] An empty completed_experiments/ with .gitkeep

After initial commit, the example_experiment.yaml from this bundle goes into pending_experiments/ as the first artefact to run as a smoke test.

---

*Companion: `README.md` in this bundle for setup sequence and runner pseudocode. `ARIA_Dashboard_Experiment_Artefact_Spec.md` for the artefact format spec.*
