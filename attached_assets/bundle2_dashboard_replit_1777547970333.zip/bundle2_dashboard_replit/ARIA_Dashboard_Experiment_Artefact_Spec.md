# ARIA Dashboard & Experiment Artefact — Specification

*The interaction model that replaces terminal-pasting with structured artefacts dropped into a dashboard. Drafted 30 April 2026, before the dashboard exists, so the artefact format works either as input to a future dashboard or as input to manual CLI invocations of v2's asie_hub.*

---

## The problem this solves

Pasting terminal commands into Claude conversations is disengaging. Dr Ferrier is a researcher and a creator, not a sysadmin. The current interaction model forces sysadmin behaviour to access work the tool can do for him.

The right interaction model is:

1. Dr Ferrier describes what he wants to know
2. Claude designs the experiment as a structured YAML artefact
3. Dr Ferrier saves the artefact
4. The dashboard reads the artefact, validates it, runs it via asie_hub orchestrator, captures outputs, presents findings

The dashboard becomes the runtime; Claude becomes the experiment designer; Dr Ferrier becomes the research director — never the sysadmin.

---

## Architecture overview

```
   ┌──────────────┐         ┌──────────────────┐         ┌──────────────────┐
   │   Claude     │         │  GitHub repo     │         │     Replit       │
   │  (designer)  │ ──────> │  pending_        │ ──────> │  (dashboard +    │
   │              │   YAML  │  experiments/    │  pull   │   runtime)       │
   └──────────────┘         └──────────────────┘         └────────┬─────────┘
                                                                  │
                                                                  ▼
                                                         ┌──────────────────┐
                                                         │  asie_hub        │
                                                         │  orchestrator    │
                                                         │  (v2 CLIs)       │
                                                         └────────┬─────────┘
                                                                  │
                                                                  ▼
                                                         ┌──────────────────┐
                                                         │  findings/       │
                                                         │  outputs/        │
                                                         │  hypotheses/     │
                                                         └──────────────────┘
```

The flow:
- Claude writes an artefact (YAML or JSON) in conversation
- Dr Ferrier saves it to GitHub repo's `pending_experiments/` folder
- Replit dashboard pulls from GitHub, validates, queues
- Dashboard invokes the appropriate asie_hub CLI (`aria_orchestrator.py`, `aria_civilisation.py`, etc.)
- asie_hub writes to its existing `experiments/`, `discoveries/`, `hypotheses/`, `outputs/`, `logs/` directories
- Dashboard renders findings; Dr Ferrier reviews; findings flow back to the originating Claude project as material

---

## The experiment artefact — schema

```yaml
# Experiment artefact v1
# This is the canonical schema. All artefacts must validate against it.

experiment_id: str           # short snake_case identifier, used as filename
created_at: str              # ISO-8601, set by Claude when drafting
created_by: str              # "claude-session-YYYY-MM-DD" or similar
project: str                 # "hum" | "book3" | "civilisational" | "art_soul_ai"

# What's being asked
question: str                # the research question, plain language, one paragraph max
hypothesis: str | null       # an explicit hypothesis if there is one; null otherwise
expected_outcome_types:      # what kinds of finding count as success
  - str                      # "convergence" | "divergence" | "null_finding" |
                             # "frame_extinction" | "position_imbalance" | etc.

# Where ARIA looks
channel: str | null          # one of v2's six channels, or null if cross-channel
                             # ("chronic_pain", "abi", "dementia", "perinatal",
                             #  "eating_disorder", "first_nations", null)
patterns: list[int]          # which of v2's nine reasoning patterns to apply
                             # (P1 Inversion, P2 Mechanism, P3 Cultural Archaeology,
                             #  P4 Family System, P5 Frequency Family,
                             #  P6 Naming Library, P7 Paradox, P8 Translation,
                             #  P9 Philosophical Grounding)

# How rigorous
protections:                 # which of v2's four protection layers fire
  p1_falsification: bool     # default true; set false only with explicit reason
  p2_eliza_output: bool      # default true
  p3_meta_observation: bool  # default true
  p4_independence_testing: bool  # default true
evidence_tier_threshold: str # "T1" | "T2" | "T3" — minimum tier for findings
convergence_requirement: str # "strong_with_falsification" | "partial_acceptable" |
                             # "any_signal_useful"

# Sources
include_layers:              # which corpus layers to draw from
  - str                      # "L1" through "L8" from corpus expansion spec
include_connectors:          # specific connectors if narrower than layers
  - str
exclude_connectors:          # specific exclusions
  - str
silo_aware: bool             # default true; never override without explicit reason

# Frame inventory (second-order discipline)
frames_expected:             # what frames the question could be approached from
  - str                      # "epidemiological", "phenomenological",
                             # "indigenous_relational", "policy",
                             # "philosophical", "design", etc.
frames_explicitly_excluded:  # what frames the experiment chooses NOT to use
  - str                      # with rationale field expected
frames_excluded_rationale:
  str:                       # frame name → rationale string
    str

# Dissonance (Atlan / second-order discipline)
dissonance_budget: float     # 0.0 to 1.0 — proportion of results from counter-corpus
                             # 0.0 = pure relevance, 0.5 = balanced, 1.0 = noise
                             # typical: 0.15-0.20 for empirical, 0.30 for theoretical
position_privilege_balance:  # what proportion of results from each position
  state_admin: float
  credentialed_research: float
  community_curated: float
  indigenous_scholarship: float
  theoretical_tradition: float
  # values sum to ~1.0; null entries mean "no constraint"

# Voice (output specification)
output_voice: str            # "academic_only" | "ferrier_popular_only" |
                             # "academic_first_then_ferrier" | "raw_findings_only"
output_format: str           # "report" | "structured_data" | "annotated_results" |
                             # "convergence_map" | "frame_inventory_only"

# Constraints
budget_cap_aud: float        # cost ceiling for the run
iteration_cap: int           # maximum reasoning iterations
time_cap_seconds: int        # wall-clock ceiling
require_human_review: bool   # if true, dashboard pauses before final synthesis

# Observer (second-order discipline — required field)
observer_note: str           # who is asking this question, in what role,
                             # in what conversational context
                             # (e.g. "Dr Ferrier, drafting Book 3 Chapter 4
                             #  on reciprocal community as load-bearing requirement")

# Reflexivity (optional but encouraged)
reflexivity_questions:       # questions about the question itself
  - str                      # e.g. "Is this question shaped by which
                             #  literatures we've already ingested?"
                             # e.g. "What would this question look like
                             #  from a refusal-as-method standpoint?"
```

---

## Mandatory fields

The schema has many optional fields. The mandatory ones are:

- `experiment_id`
- `project`
- `question`
- `expected_outcome_types`
- `evidence_tier_threshold`
- `convergence_requirement`
- `output_voice`
- `output_format`
- `budget_cap_aud`
- `observer_note`

Anything not specified takes the schema's default. Defaults are conservative (all four protections on, silo_aware true, low dissonance, modest budget cap).

---

## A worked example

Here's an experiment Claude might draft if Dr Ferrier asks: *"I want to know whether the four-requirements convergence (regulated nervous system, genuine agency, reciprocal community, contact with non-human world) actually holds across cultures, or whether it's a Western projection."*

```yaml
experiment_id: four_requirements_cross_cultural_validity
created_at: 2026-04-30T09:45:00Z
created_by: claude-session-2026-04-30
project: book3

question: >
  Does the four-requirements convergence framework (regulated nervous system,
  genuine agency over reality that pushes back, reciprocal community, contact
  with non-human world) hold up cross-culturally, or does it encode Western
  individualist assumptions in its choice of "requirements" that other
  traditions would not name?

hypothesis: >
  The four-requirements framework, while drawing on cross-cultural empirical
  literature (Frankl, SDT, Indigenous scholarship), may itself be structured
  by a Western framing that treats the requirements as discrete and individually
  measurable. Indigenous, Buddhist, and Ubuntu-derived frameworks may describe
  the same phenomenon in non-discrete, relational terms that the
  four-requirements grid cannot capture without distortion.

expected_outcome_types:
  - convergence       # is there cross-cultural agreement on something?
  - divergence        # do framings diverge incompatibly?
  - frame_extinction  # which framings have dropped out of recent literature?

channel: null         # cross-channel — civilisational
patterns: [1, 3, 9]   # P1 Inversion, P3 Cultural Archaeology, P9 Philosophical Grounding

protections:
  p1_falsification: true
  p2_eliza_output: true
  p3_meta_observation: true
  p4_independence_testing: true
evidence_tier_threshold: T2
convergence_requirement: strong_with_falsification

include_layers: [L1, L3, L4, L5, L6, L7]   # cybernetics + adjacent + Indigenous
                                            # methodologies + Australian First
                                            # Nations + refusal + counter-corpus
include_connectors: []
exclude_connectors: []
silo_aware: true

frames_expected:
  - western_individualist_psychology
  - indigenous_relational
  - buddhist_interdependence
  - ubuntu_communal
  - phenomenological
  - cybernetic_systems
frames_explicitly_excluded: []
frames_excluded_rationale: {}

dissonance_budget: 0.30   # high — this is a foundational question
position_privilege_balance:
  credentialed_research: 0.40
  indigenous_scholarship: 0.30
  theoretical_tradition: 0.20
  community_curated: 0.10

output_voice: academic_first_then_ferrier
output_format: convergence_map

budget_cap_aud: 5.00
iteration_cap: 15
time_cap_seconds: 600
require_human_review: true

observer_note: >
  Dr Ferrier is working on Chapter 4 of What Remains (Book 3 academic version),
  the chapter that argues the four-requirements framework as load-bearing for
  the civilisational thesis. Before the chapter commits to the framework, he
  wants ARIA to test whether the framework itself is a Western artefact or a
  cross-cultural finding. This is an apparatus-stress-test experiment, not a
  data-gathering experiment. Honest null findings ("we cannot tell from this
  evidence base") are valuable.

reflexivity_questions:
  - >
    Is the very phrasing "requirements" already a Western individualist framing?
    What would the equivalent question look like from a Yarning or Ubuntu standpoint?
  - >
    Has ARIA's existing corpus over-represented frameworks that share assumptions
    with the four-requirements model? What's the position-privilege distribution
    across our existing Book 3 sources to date?
```

The artefact is human-readable, machine-parseable, complete. Dr Ferrier saves it. The dashboard runs it. Findings come back as a convergence map plus an honest accounting of what the evidence base couldn't say.

---

## Dashboard requirements (minimum viable)

What the Replit dashboard must do, in priority order:

### Tier 1 — must-have for V0

1. **Read experiment artefacts from a folder.** Pull from GitHub repo's `pending_experiments/`. Validate each against the schema. Flag invalid artefacts with line-level errors.
2. **Run experiments via asie_hub CLIs.** Map artefact fields to CLI flags and arguments for `aria_orchestrator.py` and `aria_civilisation.py`. Capture stdout/stderr.
3. **Display experiments in progress.** Status (queued / running / complete / failed), elapsed time, current iteration, current cost.
4. **Display findings.** Render outputs from asie_hub's `outputs/` directory. Markdown rendering. Citation links. Position-privilege tags visible.
5. **Honour budget caps and iteration caps.** Hard stop at the cap; mark as truncated.

### Tier 2 — should-have for V1

6. **Findings index.** Searchable list of all completed experiments with their question and key findings.
7. **Cross-experiment view.** When multiple experiments touch the same question, surface convergence/divergence between their findings.
8. **Reflexivity report.** Quarterly auto-generated summary of what ARIA has been asked, what frames have dominated, what's gone unasked.
9. **Position-privilege rebalancing.** When a result set is heavily skewed (e.g. 90% credentialed research), surface the imbalance and suggest a rebalance experiment.
10. **Artefact templates.** Common experiment shapes pre-filled (e.g. "channel-specific therapeutic finding", "cross-cultural validity test", "frame-extinction audit").

### Tier 3 — nice-to-have for V2+

11. Dr Ferrier writes an experiment in the dashboard UI without going via Claude (for simple cases).
12. Dashboard suggests follow-up experiments based on completed findings.
13. Multi-user (Ralph, Juniper, Eric Sapp, etc.) with role-based permissions.
14. Public-facing read-only view of selected non-sensitive experiments.

---

## GitHub repo structure (proposed)

```
aria-dashboard/                        # repo root
├── README.md
├── pending_experiments/               # Dr Ferrier drops artefacts here
│   ├── exp_001_..._.yaml
│   └── exp_002_..._.yaml
├── completed_experiments/             # dashboard moves here after run
│   └── 2026-04-30_exp_001/
│       ├── artefact.yaml
│       ├── stdout.log
│       ├── findings.md
│       └── findings_metadata.json
├── schemas/
│   └── experiment_artefact_v1.json    # JSON schema for validation
├── dashboard/                         # Replit-deployed app code
│   ├── app.py                         # or whatever framework
│   ├── runner.py                      # asie_hub invocation
│   ├── validator.py                   # schema validation
│   ├── findings_renderer.py
│   └── ...
├── requirements.txt                   # or equivalent
└── .replit                            # Replit config
```

The convention: experiments live as files. Files version with git. The dashboard is a thin layer over filesystem operations and CLI invocations.

---

## Why YAML, why filesystem-based

Three reasons:

**Human-readable.** YAML artefacts are reviewable as text. Dr Ferrier can read what Claude designed before saving it. Disagreement points are visible.

**Versionable.** Files in git produce a clean audit trail. What was asked, when, by whom, with what parameters. The strange-loop discipline (ARIA studies its own behaviour) requires this trail.

**Portable.** No database lock-in. The dashboard could be rewritten in any framework; the artefacts persist independently. If Replit goes away, the work doesn't.

JSON would also work. YAML is preferred for human-authored content; JSON for machine-validated content. The schema is a JSON schema; the artefacts are YAML files that conform to it.

---

## Migration path from current state

Where we are now: Dr Ferrier pastes terminal commands; Claude generates them; nothing is structured.

Where this gets us:

**Step 1 — schema lock (1 conversation).** Settle the schema (this document is V0). Lock it. Save as `experiment_artefact_v1.json` in the repo.

**Step 2 — Claude produces artefacts (immediate).** From the next experiment onwards, Claude produces YAML artefacts in conversation rather than terminal commands. Dr Ferrier saves them to the `pending_experiments/` folder. They can be run manually for now (a single command takes the YAML as argument).

**Step 3 — minimal runner (1–2 days of focused Replit work).** A script that reads YAML, validates, invokes asie_hub CLI with mapped arguments, captures output to `completed_experiments/`. Not yet a dashboard; just a runner.

**Step 4 — basic dashboard (3–5 days).** Replit-deployed web UI for the V0 features (Tier 1 above). Dashboard UI is a thin layer over the runner.

**Step 5 — V1 features (rolling).** Findings index, cross-experiment view, reflexivity report. As bandwidth allows.

The benefit accrues from Step 2 onwards. Even without a dashboard, Dr Ferrier stops pasting terminal commands. The dashboard makes the workflow nicer; it's not a precondition for the structural improvement.

---

## What the artefact pattern protects against

This pattern was designed to protect against several failure modes that have hurt earlier ARIA work:

**The rebuild-the-system trap.** Previously, asking ARIA to do something new led to building new code. The artefact pattern means new questions become new artefacts, not new architectures. The orchestrator stays stable; the artefacts vary.

**The terminal-as-interface trap.** Previously, the interface was the CLI. That punishes non-coders. The artefact pattern moves the interface to a structured document the user actually reads.

**The lost-experiments trap.** Previously, an experiment's logic lived in a paste-once command and then was lost. The artefact pattern means every experiment is a file that persists, can be re-run, can be cited in book chapters.

**The opaque-rationale trap.** Previously, the *why* of an experiment lived in the conversation that produced it. The artefact pattern means the rationale is a field in the artefact (`observer_note`, `reflexivity_questions`). The why persists with the what.

---

## Discipline reminders

A few rules worth being explicit about:

- The `observer_note` field is mandatory. An experiment without an observer note is incomplete and the dashboard refuses it.
- The `silo_aware` field defaults to true. Setting it false requires explicit rationale in the artefact.
- The `dissonance_budget` field is a parameter, not a default. Every artefact sets it consciously.
- The `frames_expected` field is mandatory for any experiment touching theoretical or contested territory.
- Findings labelled "convergence" must include the falsification step (per v2's protection layer 1) or auto-downgrade to "partial".

These disciplines live in schema validation, not in good intentions. The dashboard refuses non-conforming artefacts.

---

*Companion files: `ARIA_Architectural_Map.md` (v2's six channels and four protections), `ARIA_Corpus_Expansion_Specification.md` (which layers exist), `aria_connectors_config.py` (which connectors exist), `ARIA_Second_Order_Cybernetics_Frame.md` (why the artefact has frame_inventory and dissonance_budget fields).*
