# Bundle 2 — ARIA Dashboard Replit Setup

*Files for setting up the GitHub repo and Replit dashboard. The dashboard runs experiment artefacts produced by Claude in the ARIA Synthesis project against ARIA v2's asie_hub orchestrator.*

---

## What's in this bundle

- **`ARIA_Dashboard_Experiment_Artefact_Spec.md`** — full specification of the artefact format, the dashboard architecture, and the migration path from current state. Read this first.
- **`experiment_artefact_v1.json`** — JSON schema for validating artefacts. Used by the dashboard to reject malformed input.
- **`example_experiment.yaml`** — worked example of a complete artefact (the four-requirements cross-cultural validity test from the spec).
- **`repo_structure.md`** — proposed GitHub repository layout.
- **`README.md`** — this file.

---

## Setup sequence

### Step 1 — Create GitHub repo

```bash
# On GitHub: create repo called "aria-dashboard" under the bazmahti account
# Locally:
git clone https://github.com/bazmahti/aria-dashboard.git
cd aria-dashboard

# Create the directory structure
mkdir -p pending_experiments completed_experiments schemas dashboard

# Drop in the schema and example
cp /path/to/bundle2/experiment_artefact_v1.json schemas/
cp /path/to/bundle2/example_experiment.yaml pending_experiments/

# Initial commit
git add .
git commit -m "Initial dashboard structure"
git push origin main
```

### Step 2 — Connect Replit

1. Create new Replit project, "Import from GitHub"
2. Connect to `bazmahti/aria-dashboard` repo
3. Replit will auto-detect the language/framework once the dashboard code lands

### Step 3 — Build minimal runner (V0)

The minimum viable runner reads YAML, validates against the schema, invokes asie_hub, captures output. Pseudocode:

```python
# dashboard/runner.py (skeleton)

import yaml
import json
import jsonschema
import subprocess
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).parent.parent
PENDING = ROOT / "pending_experiments"
COMPLETED = ROOT / "completed_experiments"
SCHEMA_PATH = ROOT / "schemas" / "experiment_artefact_v1.json"

with open(SCHEMA_PATH) as f:
    SCHEMA = json.load(f)


def validate(artefact: dict) -> list[str]:
    """Return list of validation errors, empty if valid."""
    errors = []
    validator = jsonschema.Draft7Validator(SCHEMA)
    for err in validator.iter_errors(artefact):
        errors.append(f"{'.'.join(map(str, err.path))}: {err.message}")
    return errors


def map_to_cli_args(artefact: dict) -> list[str]:
    """Translate artefact fields to asie_hub CLI arguments."""
    args = ["python3", "/path/to/asie_hub/aria_orchestrator.py"]
    
    if artefact.get("channel"):
        args.extend(["--channel", artefact["channel"]])
    
    args.extend(["--patterns", ",".join(map(str, artefact["patterns"]))])
    args.extend(["--evidence-tier", artefact["evidence_tier_threshold"]])
    args.extend(["--budget-cap", str(artefact["budget_cap_aud"])])
    
    # Map protections
    protections = artefact.get("protections", {})
    if not protections.get("p1_falsification", True):
        args.append("--no-p1")
    # ... similar for other protections
    
    # Pass the question as the actual prompt
    args.extend(["--question", artefact["question"]])
    
    return args


def run_experiment(artefact_path: Path) -> Path:
    """Run a single experiment, return path to completed_experiments/ folder."""
    with open(artefact_path) as f:
        artefact = yaml.safe_load(f)
    
    errors = validate(artefact)
    if errors:
        raise ValueError(f"Artefact invalid:\n" + "\n".join(errors))
    
    # Create completed folder
    timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d_%H%M%S")
    folder = COMPLETED / f"{timestamp}_{artefact['experiment_id']}"
    folder.mkdir(parents=True, exist_ok=True)
    
    # Copy the artefact
    (folder / "artefact.yaml").write_text(artefact_path.read_text())
    
    # Run asie_hub
    cli_args = map_to_cli_args(artefact)
    result = subprocess.run(
        cli_args,
        capture_output=True,
        text=True,
        timeout=artefact.get("time_cap_seconds", 600),
    )
    
    (folder / "stdout.log").write_text(result.stdout)
    (folder / "stderr.log").write_text(result.stderr)
    (folder / "findings.md").write_text(result.stdout)  # asie_hub outputs markdown
    
    # Move artefact out of pending
    artefact_path.unlink()
    
    return folder


if __name__ == "__main__":
    for artefact_path in PENDING.glob("*.yaml"):
        print(f"Running {artefact_path.name}...")
        try:
            folder = run_experiment(artefact_path)
            print(f"  → completed: {folder}")
        except Exception as e:
            print(f"  ! failed: {e}")
```

This is the V0 runner. It's not a dashboard yet — just a script. But it implements the artefact pattern.

### Step 4 — Build dashboard UI (V1)

Pick a framework (Flask, FastAPI, Streamlit, whatever Replit deploys cleanly). Wrap the runner. Render findings. Add the Tier 1 dashboard features from the spec:

- List experiments in pending/running/complete states
- Display findings
- Show budget consumed
- Honour caps

### Step 5 — Iterate

Tier 2 and Tier 3 features (findings index, cross-experiment view, reflexivity report) follow once V1 is stable.

---

## Integration with asie_hub

The dashboard does **not** replace asie_hub. It invokes asie_hub. Specifically:

- `aria_orchestrator.py` for therapeutic-channel experiments
- `aria_civilisation.py` for civilisational experiments
- `aria_meta_synthesis.py` for the six-dimension meta-synthesis
- `aria_methodology.py` for methodology audits

The dashboard's job is to:

1. Read the artefact
2. Choose the right asie_hub CLI based on `project` and `channel` fields
3. Map artefact fields to CLI flags
4. Invoke
5. Capture and present findings

asie_hub does the actual research work. The dashboard is the orchestration and presentation layer.

---

## What's not in this bundle

- The dashboard application code (Flask/FastAPI/Streamlit) — that's the build work, not the spec.
- A populated database of experiments — the artefact pattern is filesystem-based by design.
- Authentication/multi-user — single-user for V0/V1; multi-user is V2+.

---

## Estimated build time

- **Step 1** (repo setup): 30 minutes
- **Step 2** (Replit connect): 30 minutes
- **Step 3** (V0 runner): 1–2 days of focused coding
- **Step 4** (V1 dashboard UI): 3–5 days of focused work
- **Total to V1**: roughly one focused week

The benefit accrues from Step 2 (artefact pattern) onwards even before the dashboard is built. So Steps 3–4 are an investment in nicer UX, not a blocker for the structural improvement.

---

## Where this bundle goes

Drop it into the GitHub repo `bazmahti/aria-dashboard` (or whatever name you choose). The spec document and schema are versioned with the dashboard code. The example experiment lives in `pending_experiments/` as a starting template.

---

*Companion: Bundle 1 (Project Knowledge) for the Claude side that produces the artefacts. Bundle 3 (Archive) for the v3 sandbox and YarnAI work that lives elsewhere.*
