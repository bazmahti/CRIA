# CRIA v2 Upgrade Notes

## What Changed and Why

### 1. Evidence Firewall (Critical Fix)

**Problem:** When database searches returned irrelevant results, the Academic pipeline
synthesised from Claude's training knowledge without flagging this. The methodology
sections claimed systematic database retrieval when synthesis may have drawn on
background LLM knowledge.

**Fix:** 
- `Finding.is_retrieved: bool` now tracks provenance of every finding
- `Finding.retrieved_papers: List[Paper]` carries actual retrieved documents
- `call_llm()` has `enforce_evidence_firewall=True` mode that:
  - Prepends the full `_EVIDENCE_FIREWALL_INSTRUCTION` to the system prompt
  - Appends retrieved papers as the only evidence source
  - Explicitly prohibits introducing non-retrieved claims
- Academic rendering uses firewall mode exclusively
- If retrieval returns < 3 papers, Academic output explicitly documents
  the failure rather than substituting LLM knowledge

### 2. Stage 0 Pre-Retrieval Intelligence (New)

**Problem:** `CogC2_Evidence` used the raw research question as the search string,
with no vocabulary mapping, connector routing, or per-sub-question iteration budgets.

**Fix:** `Stage0PreRetrievalIntelligence` runs before any database search and produces
a `ResearchDesignRecord` containing:
- Concept vocabulary map (disciplinary terminologies)
- Connector selection with documented rationale
- Tailored search strings per connector
- Sub-question decomposition
- Variable iteration budgets per sub-question
- Hypothesis seeds for Contradiction and Serendipity channels

The `ResearchDesignRecord` forms the published methodology section via
`to_methodology_statement()`. This is the legitimate use of LLM training
knowledge: shaping how we search, not what we find.

### 3. Connector Review (New)

**Problem:** Retrieval failures routed back into the iterative loop indefinitely.
No mechanism to distinguish query problems from infrastructure problems from
sovereignty gaps.

**Fix:** `ConnectorReview` triggers on `RetrievalExhaustionSignal` and classifies
failure as one of:
- `QUERY_VOCABULARY` → reformulate search terms, retry
- `CONNECTOR_COVERAGE` → try inactive connectors, generate `ConnectorGapReport`
- `SOVEREIGNTY_GAP` → generate `PartnershipRecommendation`, do NOT retry as search
- `TRUE_ABSENCE` → generate `ConfirmedAbsenceRecord`, trigger experiment generation

### 4. New Experiment Generation (New)

**Problem:** Confirmed evidence absence was treated as system failure. No mechanism
to convert absence into actionable research design.

**Fix:** `NewExperimentGenerator` converts `ConfirmedAbsenceRecord` into
`ExperimentArtefact` containing:
- Precise research question (from the confirmed gap)
- Justification from absence documentation
- Methodological design
- Infrastructure requirements
- Iteration budget estimate
- Evidence dependency map

`ExperimentArtefact` persists to the `experiment_queue` database table and is
returned in the API response. Publishable as a research gap paper.

### 5. Security (All New)

- **CORS:** `CORSMiddleware` with configurable `CRIA_ALLOWED_ORIGINS` env var
- **Rate limiting:** `slowapi` — 5 research requests/minute, 30 status polls/minute
- **Input validation:** Pydantic `field_validator` sanitises query (removes null bytes,
  trims whitespace). `max_length=2000` on query, `max_length=500` on observer_note.
- **API key auth:** Optional (`CRIA_REQUIRE_API_KEY=true`). When enabled, requires
  `X-API-Key` header matching `CRIA_API_KEY`.
- **Request ID:** Every response gets `X-Request-ID` header for tracing.
- **Structured logging:** All `print()` calls replaced with `log.warning()` etc.
- **Health check:** Returns DB connection status.

### 6. Dead Code Removed

- `PositionPrivileged.STATE_ADMINISTRATIVE` alias (duplicate of `STATE_ADMIN`)
- `random.uniform(3.5, 4.8)` novelty scores in Serendipity (fake randomness)
  replaced with honest fixed estimate (3.5)
- Duplicate `/api/research/unified` endpoint (was identical to `/cria-unified/research`)
- Ultraria proxy routes (extracted — they proxied to an offline service)
- `DASHBOARD_HTML` massive inline string (now redirects to health endpoint;
  proper dashboard should be a separate served HTML file)

### 7. Code Quality

- All `print()` → `log.warning()` / `log.info()` / `log.error()`
- Model reference `gpt-5.1` → `MODEL_NAME` env var (default: `claude-sonnet-4-20250514`)
- Connector schema unified: `cria_connectors_config.Connector` and `main.ConnectorSpec`
  merged into single `ConnectorSpec` with `AccessMode` field
- `StubbedConnector` results tagged with `is_stub=True` and excluded from retrieved
  evidence sets
- `inactive_connectors()` function added alongside `active_connectors()` and `gated_connectors()`
- Database schema extended with `experiment_queue` table and `request_id` column

### 8. New Database Table

```sql
CREATE TABLE experiment_queue (
    id                          UUID PRIMARY KEY,
    experiment_id               TEXT UNIQUE NOT NULL,
    status                      TEXT NOT NULL DEFAULT 'pending',
    source_job_id               TEXT,
    question                    TEXT NOT NULL,
    justification               TEXT,
    design                      JSONB,
    infrastructure_requirements JSONB,
    iteration_budget_estimate   INTEGER,
    evidence_dependency_map     JSONB,
    connector_gap_report        JSONB,
    partnership_recommendation  JSONB,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 9. New Environment Variables

| Variable | Default | Purpose |
|---|---|---|
| `CRIA_MODEL_NAME` | `claude-sonnet-4-20250514` | LLM model for all calls |
| `CRIA_ALLOWED_ORIGINS` | `*` | Comma-separated CORS origins |
| `CRIA_REQUIRE_API_KEY` | `false` | Enable API key auth |
| `CRIA_API_KEY` | `""` | API key when auth enabled |
| `CRIA_CONTACT_EMAIL` | `research@example.org` | Polite-pool header for APIs |
| `SEMANTIC_SCHOLAR_KEY` | `""` | Optional Semantic Scholar API key |

### 10. New Requirements

```
slowapi>=0.1.9
```

Add to `requirements.txt`.

## Migration from v1

1. Rename `main.py` → `main_v1_backup.py`
2. Place `main_v2.py` as `main.py`
3. Install new dependency: `pip install slowapi`
4. Set `CRIA_MODEL_NAME` in Replit secrets if not using the default
5. Run the app — the DB migration runs automatically on startup and creates
   the `experiment_queue` table
6. Run the verification tests described in the Methodology Review document

## What Was NOT Changed

The core architectural design is preserved:
- Three-pipeline architecture (Cognitive, Epistemic, Convergent)
- 10 + 10 + 5 channel structure
- Layer 3 meta-cognitive learning
- Hofstadter validators
- Position-privilege accounting
- Refusal-as-finding protocols
- Frame archaeology
- Sovereignty gap handling
- Publication guidance engine
- Three-voice rendering (Academic, Editorial, Practitioner)
- Pipeline-differentiated paper rendering

These are correct and working. The upgrade fixes the evidence provenance gap,
adds adaptive retrieval, adds security, and removes dead code. The epistemological
architecture is intact.

## Verification Tests

Run these after deployment to confirm the upgrade is working:

1. **Evidence firewall test:** Submit a query on a topic where Claude has training
   knowledge but database search is unlikely to return relevant papers (e.g., a very
   niche specialist topic). Verify Academic output says "Insufficient retrieved evidence"
   rather than producing a synthesised paper with invented citations.

2. **Stage 0 test:** Check `/research/{job_id}` response includes `research_design_record`
   with non-empty `search_strings` that differ from the raw query.

3. **Variable iteration budget test:** Submit two queries — one on a well-indexed topic,
   one on a specialist topic. Verify `iteration_budgets` differ in the design record.

4. **Connector review test:** Submit a query in a domain not well-covered by active
   connectors (e.g., parapsychology, contemplative neuroscience). Verify response includes
   `connector_gap_reports` with new connector recommendations.

5. **New experiment test:** Submit a very narrow or niche query likely to return no
   relevant papers. Verify response includes `new_experiments` with a structured
   `ExperimentArtefact`.

6. **Security test:** Try submitting a query > 2000 characters. Verify 422 validation error.
   Try submitting with `CRIA_REQUIRE_API_KEY=true` without a key. Verify 401.

7. **Rate limiting test:** Submit > 5 research requests in 60 seconds from same IP.
   Verify 429 on the 6th request.
