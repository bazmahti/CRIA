# CRIA v2 — Replit Deployment Instructions

## Files in this package

- `main_v2.py`        — The upgraded CRIA engine (replace existing main.py)
- `requirements.txt`  — Updated dependencies (adds slowapi)
- `UPGRADE_NOTES.md`  — Full change documentation
- `DEPLOY_README.md`  — This file

## Steps

### 1. Back up current main.py
In the Replit shell:
```
cp artifacts/cria-unified/main.py artifacts/cria-unified/main_v1_backup.py
```

### 2. Upload the new files
Upload from this zip into the Replit file tree:
- `main_v2.py`       → artifacts/cria-unified/main.py
- `requirements.txt` → artifacts/cria-unified/requirements.txt

### 3. Install new dependency
In the Replit shell:
```
pip install slowapi>=0.1.9
```
Or Replit will pick it up automatically from requirements.txt on next run.

### 4. Set environment variables (Replit Secrets)
Required (already set):
- DATABASE_URL
- AI_INTEGRATIONS_OPENAI_API_KEY
- AI_INTEGRATIONS_OPENAI_BASE_URL

New optional variables:
- CRIA_MODEL_NAME         → default: claude-sonnet-4-20250514
- CRIA_ALLOWED_ORIGINS    → default: * (set to your domain in production)
- CRIA_REQUIRE_API_KEY    → default: false (set true to enable auth)
- CRIA_API_KEY            → your chosen key if auth is enabled
- CRIA_CONTACT_EMAIL      → for API polite-pool headers
- SEMANTIC_SCHOLAR_KEY    → optional Semantic Scholar API key

### 5. Restart the Repl
The database migration runs automatically on startup and creates
the new experiment_queue table.

### 6. Verify deployment
Hit the health endpoint:
```
GET /cria-unified/health
```
Should return:
```json
{
  "status": "ok",
  "version": "CRIA 2.0",
  "db": "connected",
  "pipelines": ["cognitive", "epistemic", "convergent"],
  "active_connectors": 18,
  "inactive_connectors": 6,
  "gated_connectors": 4
}
```

### 7. Run verification tests
See UPGRADE_NOTES.md Section "Verification Tests" for the 7 tests
that confirm the evidence firewall, Stage 0, and security are working.

## What changed (summary)
- Evidence firewall: Academic synthesis draws only from retrieved papers
- Stage 0: Pre-retrieval intelligence designs searches before querying
- Connector Review: classifies retrieval failures, routes to gap reports
- New Experiment Generation: confirmed absences become experiment artefacts
- Security: CORS, rate limiting, input validation, request ID tracing
- Dead code removed: ~1,000 lines eliminated
- All print() replaced with structured logging
- Model name is now environment-controlled
