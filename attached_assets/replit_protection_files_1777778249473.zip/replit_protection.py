"""
replit_protection.py — Drop-in IP protection for Replit-deployed FastAPI apps.

Reusable across all of Dr Barry Ferrier's Replit projects (CRIA, HUM, OCAA, etc.).

Integration (three lines in your main.py):

    from fastapi import FastAPI
    from replit_protection import setup_protection

    app = FastAPI()
    setup_protection(app)

    # ... rest of your routes unchanged ...

Required Replit Secret:
    PROTECTION_PASSWORD — strong password (generate with secrets.token_urlsafe(24))

Optional Replit Secrets:
    PROTECTION_USERNAME       — default: "researcher"
    PROTECTION_PUBLIC_PATHS   — comma-separated, default: "/health,/robots.txt"
    PROTECTION_ENABLE_AUTH    — "true" or "false", default: "true"

What this provides:
    1. HTTP Basic Auth on all routes (except declared public paths)
    2. /robots.txt route — blocks AI training crawlers, allows conversational
       fetchers (Claude-User, ChatGPT-User), so you can still ask an AI to view
       your own page on demand
    3. Security headers on every response — X-Robots-Tag: noindex, X-Frame-Options,
       X-Content-Type-Options, Referrer-Policy

What this does NOT provide (intentionally — use the right tool for the job):
    - Rate limiting → Cloudflare in front of Replit
    - DDoS protection → Cloudflare
    - Per-user accounts → out of scope; use a real auth provider for that
    - Content-Security-Policy tuned for your dashboard → set per-project
"""

import base64
import os
import secrets
from typing import Optional, Set

from fastapi import FastAPI, Request, Response
from fastapi.responses import PlainTextResponse
from starlette.middleware.base import BaseHTTPMiddleware


# ---------------------------------------------------------------------------
# robots.txt — selective AI crawler policy
# ---------------------------------------------------------------------------
# Conversational fetchers (used when a human asks an AI to retrieve this page
# in real time) are ALLOWED. Training crawlers (used to ingest content for
# model training) are BLOCKED. This preserves the "ask Claude to look at my
# dashboard" workflow while opting out of training corpora.
#
# robots.txt is advisory — compliant crawlers honour it; malicious scrapers
# ignore it. This is the legal/ethical opt-out layer; auth (above) is the
# technical layer.

ROBOTS_TXT = """\
# IP protection — see https://www.anthropic.com/news/claude-bot for context
# AI training crawlers are blocked. Conversational AI fetchers are allowed
# so the site owner can ask an AI assistant to view this page in real time.

# === Conversational AI fetchers — ALLOWED ===
User-agent: Claude-User
Allow: /

User-agent: ChatGPT-User
Allow: /

User-agent: PerplexityBot-User
Allow: /

# === AI training crawlers — BLOCKED ===
User-agent: ClaudeBot
Disallow: /

User-agent: anthropic-ai
Disallow: /

User-agent: GPTBot
Disallow: /

User-agent: Google-Extended
Disallow: /

User-agent: CCBot
Disallow: /

User-agent: PerplexityBot
Disallow: /

User-agent: Applebot-Extended
Disallow: /

User-agent: Bytespider
Disallow: /

User-agent: Meta-ExternalAgent
Disallow: /

User-agent: meta-externalagent
Disallow: /

User-agent: Amazonbot
Disallow: /

User-agent: cohere-ai
Disallow: /

User-agent: Diffbot
Disallow: /

User-agent: Omgilibot
Disallow: /

User-agent: FacebookBot
Disallow: /

User-agent: ImagesiftBot
Disallow: /

User-agent: TimpiBot
Disallow: /

# === Default ===
# Other crawlers allowed at robots level, but X-Robots-Tag: noindex is set
# on every response by the security headers middleware, so search engines
# will not index the site.
User-agent: *
Allow: /
"""


# ---------------------------------------------------------------------------
# HTTP Basic Auth check
# ---------------------------------------------------------------------------

def _check_basic_auth(
    auth_header: Optional[str],
    expected_user: str,
    expected_pass: str,
) -> bool:
    """Constant-time check of an HTTP Basic Auth header."""
    if not auth_header or not auth_header.startswith("Basic "):
        return False
    try:
        decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
        username, _, password = decoded.partition(":")
    except (ValueError, UnicodeDecodeError):
        return False
    user_ok = secrets.compare_digest(username, expected_user)
    pass_ok = secrets.compare_digest(password, expected_pass)
    return user_ok and pass_ok


# ---------------------------------------------------------------------------
# Combined protection middleware (auth + security headers)
# ---------------------------------------------------------------------------

class ProtectionMiddleware(BaseHTTPMiddleware):
    """Adds HTTP Basic Auth + safe security headers to every response."""

    def __init__(
        self,
        app,
        username: str,
        password: str,
        public_paths: Set[str],
        enable_auth: bool,
    ):
        super().__init__(app)
        self.username = username
        self.password = password
        self.public_paths = public_paths
        self.enable_auth = enable_auth

    async def dispatch(self, request: Request, call_next):
        # ---- Auth gate ----
        if self.enable_auth and request.url.path not in self.public_paths:
            auth_header = request.headers.get("authorization")
            if not _check_basic_auth(auth_header, self.username, self.password):
                return Response(
                    content="Unauthorized — protected research instrument",
                    status_code=401,
                    headers={
                        "WWW-Authenticate": 'Basic realm="Protected Research Instrument"',
                        "X-Robots-Tag": "noindex, nofollow, noarchive",
                    },
                )

        # ---- Pass through to app ----
        response = await call_next(request)

        # ---- Security headers on every response ----
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["X-Robots-Tag"] = "noindex, nofollow, noarchive"
        response.headers["Permissions-Policy"] = (
            "geolocation=(), microphone=(), camera=(), interest-cohort=()"
        )
        # Conservative-but-not-paranoid CSP. Adjust per-project if you need
        # external CDNs, inline scripts, etc.
        response.headers.setdefault(
            "Content-Security-Policy",
            "default-src 'self'; "
            "script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; "
            "img-src 'self' data: https:; "
            "connect-src 'self'; "
            "frame-ancestors 'none'",
        )
        return response


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def setup_protection(app: FastAPI) -> None:
    """
    Wire IP protection into a FastAPI app. Call once, right after `app = FastAPI()`.

    Reads from environment (Replit Secrets):
      PROTECTION_PASSWORD       (required if auth enabled)
      PROTECTION_USERNAME       (default: "researcher")
      PROTECTION_PUBLIC_PATHS   (default: "/health,/robots.txt")
      PROTECTION_ENABLE_AUTH    (default: "true")

    Raises:
      RuntimeError if auth is enabled but PROTECTION_PASSWORD is unset —
      fail loudly rather than silently deploy an unprotected site.
    """
    username = os.getenv("PROTECTION_USERNAME", "researcher")
    password = os.getenv("PROTECTION_PASSWORD", "")
    enable_auth = os.getenv("PROTECTION_ENABLE_AUTH", "true").lower() in ("true", "1", "yes")

    public_paths_raw = os.getenv("PROTECTION_PUBLIC_PATHS", "/health,/robots.txt")
    public_paths: Set[str] = {
        p.strip() for p in public_paths_raw.split(",") if p.strip()
    }
    public_paths.add("/robots.txt")  # always public — non-negotiable

    if enable_auth and not password:
        raise RuntimeError(
            "replit_protection: PROTECTION_PASSWORD is required when auth is "
            "enabled. Set it as a Replit Secret. To disable auth temporarily "
            "(for local debugging only), set PROTECTION_ENABLE_AUTH=false."
        )

    # robots.txt route — registered before middleware so it's reachable
    @app.get("/robots.txt", response_class=PlainTextResponse, include_in_schema=False)
    async def _robots() -> str:
        return ROBOTS_TXT

    # Combined auth + security headers middleware
    app.add_middleware(
        ProtectionMiddleware,
        username=username,
        password=password,
        public_paths=public_paths,
        enable_auth=enable_auth,
    )
