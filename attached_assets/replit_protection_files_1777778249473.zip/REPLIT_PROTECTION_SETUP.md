# Replit Protection — Setup Guide

A drop-in IP protection layer for any Replit-deployed FastAPI project. Same
file, same three-line integration, same Replit Secrets pattern — applied
across CRIA, HUM, OCAA, and any future research-tool deployment.

This guide is written so an AI assistant (Claude in chat, Claude Code, or
similar) can apply the protection cleanly without further instruction.

---

## What this protects against

| Threat | Protection |
|---|---|
| Anonymous browser visitors reading your dashboard | HTTP Basic Auth |
| AI training crawlers (GPTBot, ClaudeBot, CCBot, etc.) ingesting content | robots.txt + X-Robots-Tag |
| Search engine indexing | X-Robots-Tag: noindex on every response |
| Clickjacking / iframe embedding | X-Frame-Options: DENY |
| MIME-type sniffing exploits | X-Content-Type-Options: nosniff |
| Referrer leakage to third parties | Referrer-Policy |

## What this does NOT protect against

Be honest about the limits:

- A human collaborator with the password copying outputs by hand
- Determined scrapers that ignore robots.txt
- Sophisticated attackers targeting the Replit infrastructure
- Anything in your GitHub repo (separate concern — see "Next layers" below)

---

## Installation (per Replit project)

### Step 1 — Add the module

Copy `replit_protection.py` into your project root (next to `main.py`).
No edits to the file itself — it's drop-in.

### Step 2 — Wire it into your FastAPI app

Open your `main.py`. Find the line that creates the FastAPI app — usually
something like:

```python
app = FastAPI(title="...", version="...")
```

Add two lines: an import at the top of the file, and a `setup_protection(app)`
call immediately after `app` is created:

```python
from fastapi import FastAPI
from replit_protection import setup_protection   # ← add this import

app = FastAPI(title="...", version="...")
setup_protection(app)                             # ← add this call

# ... all your existing routes stay exactly as they were ...
```

That's it. Existing routes don't need any changes.

### Step 3 — Set the Replit Secret

In Replit, click the lock icon in the left sidebar to open the Secrets pane.
Add this secret:

| Key | Value |
|---|---|
| `PROTECTION_PASSWORD` | A strong password — see below |

To generate a strong password, paste this into the Replit shell:

```bash
python -c "import secrets; print(secrets.token_urlsafe(24))"
```

Save the password in a password manager. You'll need it every time you
visit the site, and you'll share it with collaborators.

### Step 4 — Restart the Repl

Click Stop, then Run. Replit picks up the new file and the new secret on
restart. The first request after restart may be slow due to cold-start —
this is normal Replit behaviour, not an auth problem.

---

## Verification

After redeploy, confirm protection is live. Run these from a terminal:

```bash
# Set this to your project's URL
URL="https://YOUR-PROJECT.replit.app"

# 1. Root path should require auth — expect HTTP 401
curl -i "$URL/"

# 2. Auth-protected access should work — expect HTTP 200
curl -i -u researcher:YOUR_PASSWORD "$URL/"

# 3. robots.txt should be public — expect HTTP 200 with the policy
curl -i "$URL/robots.txt"

# 4. Health endpoint should be public (so monitoring works) — expect HTTP 200
curl -i "$URL/health"

# 5. Security headers should be present on every response
curl -I -u researcher:YOUR_PASSWORD "$URL/" | grep -iE "x-frame|x-robots|x-content|referrer"
```

If all five pass, the layer is working.

---

## Optional configuration

Set additional Replit Secrets only if you need to override defaults:

| Secret | Default | Use when |
|---|---|---|
| `PROTECTION_USERNAME` | `researcher` | You want a different username |
| `PROTECTION_PUBLIC_PATHS` | `/health,/robots.txt` | You have a webhook or status endpoint that needs to stay open |
| `PROTECTION_ENABLE_AUTH` | `true` | You're temporarily debugging and need to disable auth (set to `false`) |

**Important**: never disable auth on a deployment that has real research
content. The "disable" toggle is for local debugging only.

---

## Sharing access with collaborators

The model is one shared password per project. Workflow:

1. Generate the password (Step 3 above)
2. Store it in a password manager (1Password, Bitwarden, etc.)
3. Share the URL + username + password with the collaborator via the
   password manager's secure-share feature, never via email or Slack
4. When the collaborator no longer needs access, rotate the password
   (Step 3 again with a fresh value, then restart the Repl)

If you need per-collaborator revocation without rotating for everyone,
you'll outgrow Basic Auth and need a real auth provider (Auth0, Clerk,
or similar). Defer that until it actually becomes a problem.

---

## Applying to multiple Replit projects

This is the same playbook for every project:

1. Copy `replit_protection.py` to the project (no edits)
2. Add the two lines to `main.py`
3. Set `PROTECTION_PASSWORD` in that project's Secrets
4. Restart

Use a **different password per project**. Track them in a password manager.
This way, if one is ever compromised, the blast radius is one project.

For projects on a different stack (Express/Node, Flask, etc.), the same
shape applies but the code is different. Ask for an Express version when
you need it.

---

## Next layers (for when this is in place)

This module closes the largest open door — a public Replit URL anyone
can read. The full IP protection stack also includes:

1. ✅ **Replit auth + robots + security headers** — this module
2. **GitHub repos private** — Settings → General → Change visibility
3. **Secret scanning** — audit commit history (`gitleaks detect`) and
   rotate any committed API keys; never commit `.env`
4. **LICENSE + COPYRIGHT.md at repo root** — assert authorship explicitly
5. **Cloudflare in front of Replit** — bot detection, rate limiting,
   challenge pages (requires Replit Reserved VM tier and a custom domain)
6. **Collaborator IP agreements** — one-page document for anyone with
   access to private repos or shared passwords

Tackle these in order. Each one is a discrete piece of work; none
require redoing the previous ones.

---

## Compatibility notes

- **FastAPI version**: requires FastAPI ≥ 0.95 (any version with
  `BaseHTTPMiddleware` from Starlette, which is FastAPI's core).
- **Python version**: 3.9+
- **Replit AI Integrations**: compatible — auth happens before the request
  reaches your routes, so AI Integrations endpoints are also protected.
- **WebSockets**: HTTP middleware does not apply to WebSocket connections.
  If a project uses WebSockets, add auth to the WebSocket route handler
  separately. CRIA Unified does not currently use WebSockets.
- **Replit AI Integrations key (`AI_INTEGRATIONS_OPENAI_*`)**: independent
  of this module — those are LLM-vendor credentials, not user-facing auth.

---

*Compiled May 2026 for Dr Barry Ferrier's research portfolio. Reusable
across CRIA, HUM, OCAA, and any future Replit FastAPI deployment.*
