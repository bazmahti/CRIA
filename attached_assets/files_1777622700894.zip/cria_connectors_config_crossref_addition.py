# =============================================================================
# Crossref connector addition for cria_connectors_config.py
# =============================================================================
#
# To apply:
#   1. Append the CROSSREF dataclass below to cria_connectors_config.py,
#      placing it in the "Mainstream academic" section (or alongside
#      OpenAlex / arXiv / Semantic Scholar wherever those live in
#      aria_connections.py).
#   2. Add CROSSREF to the ALL_NEW_CONNECTORS list (line 402).
#   3. Implement the retrieval function in aria_connections.py — pattern
#      sketch below. The Crossref REST API is the simplest of the three:
#      no auth required, polite-pool by setting User-Agent with email,
#      stable JSON schema, no rate-limit fight if you stay under 50/sec.
#
# This is a smallest-valuable-addition change. Total LOC added across
# both files: ~50.
# =============================================================================


from dataclasses import dataclass
# (uses Connector, AccessMode, PositionPrivileged, DissonanceRole already
# defined in cria_connectors_config.py — do not redefine; just import or
# paste the entry into the existing file)


# ---------------------------------------------------------------------------
# Mainstream academic — add alongside OpenAlex / arXiv / Semantic Scholar
# ---------------------------------------------------------------------------

CROSSREF = Connector(
    name="crossref",
    access_mode=AccessMode.OPEN_ACCESS,
    layer="L1,L3,L7,L8",          # broad — used for citation triangulation
                                   # across most layers
    domains=["D6_Philosophy", "D5_Governance", "D3_Education", "D4_Meaning"],
    position_privileged=PositionPrivileged.CREDENTIALED_RESEARCH,
    dissonance_role=DissonanceRole.BRIDGE,
    base_url="https://api.crossref.org/works",
    rate_limit_per_minute=300,    # polite-pool limit; well below the
                                   # 50/sec hard limit
    notes=(
        "Crossref REST API. No auth required. Send User-Agent with "
        "contact email for polite-pool routing. Returns DOI, title, "
        "authors, abstract, references, citation count. Use for "
        "citation triangulation, reference resolution, and finding "
        "works that cite a given DOI (use /works?filter=reference.doi:X)."
    ),
)


# =============================================================================
# Retrieval pattern sketch — for aria_connections.py
# =============================================================================
#
# This is the function shape that needs to live in aria_connections.py.
# It mirrors the existing OpenAlex retrieval pattern (which the Replit
# build will already have). Do not re-invent the request/cache/error
# scaffolding; reuse whatever is already there.

"""
import httpx
from typing import Any

CROSSREF_BASE = "https://api.crossref.org/works"
CROSSREF_HEADERS = {
    # Polite-pool: identify the project + a contact email.
    # Crossref documents this as the recommended courtesy.
    "User-Agent": "CRIA/2.0 (https://example.org; mailto:contact@example.org)",
}

async def crossref_query(
    query: str,
    rows: int = 20,
    filter_str: str | None = None,
) -> list[dict[str, Any]]:
    \"\"\"
    Issue a Crossref /works query.

    Args:
        query: free-text search query (matches against title, abstract, authors).
        rows: max results (Crossref hard cap is 1000 per page; default 20).
        filter_str: optional Crossref filter expression
                    (e.g. 'from-pub-date:2020,type:journal-article').

    Returns:
        List of work-records, each a dict with at minimum:
        DOI, title, author, abstract, container-title, issued, type,
        is-referenced-by-count, reference (citations).
    \"\"\"
    params = {"query": query, "rows": rows}
    if filter_str:
        params["filter"] = filter_str

    async with httpx.AsyncClient(headers=CROSSREF_HEADERS, timeout=30.0) as client:
        resp = await client.get(CROSSREF_BASE, params=params)
        resp.raise_for_status()
        data = resp.json()
        return data.get("message", {}).get("items", [])


# Example call from a CRIA channel subagent:
#   results = await crossref_query(
#       "Wray two theories of value Minsky financial instability",
#       rows=10,
#       filter_str="type:journal-article,from-pub-date:2010"
#   )
#   for work in results:
#       title = work.get("title", [""])[0]
#       doi = work.get("DOI")
#       cited_by = work.get("is-referenced-by-count", 0)
#       # ... feed into evidence-tier classifier, layer-tagging, etc.
"""

# =============================================================================
# Notes for the SEP and nLab routing-through-Exa option
# =============================================================================
#
# These do NOT need new Connector entries. They get used through Exa with
# site-scoped queries. From within a CRIA channel that wants SEP or nLab
# content, the call shape is:
#
#   await exa_search(f"site:plato.stanford.edu {topic}")   # for SEP
#   await exa_search(f"site:ncatlab.org {topic}")          # for nLab
#
# This works today, costs nothing additional, and avoids building two
# dedicated retrieval pipelines for sources that will see <5 queries
# per experiment.
#
# If, after running the Juniper experiment, those queries turn out to be
# load-bearing and Exa's quality is insufficient — that's the point at
# which it becomes worth building dedicated SEP/nLab connectors.
# Smallest-valuable-addition discipline says: not before.
